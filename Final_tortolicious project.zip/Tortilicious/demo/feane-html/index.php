<?php

session_start();
if(!isset($_SESSION['Username'])){
    echo "You are logged out of the website, kindly login .";
    header('location: login.php');
}
?>
<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">

  <title> Tortilicious </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css"
    integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ=="
    crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Yanone+Kaffeesatz&display=swap');

    h3 {
      font-family: 'Yanone Kaffeesatz', sans-serif;
    }
    .whatsapp {
    position: fixed;
    width: 60px;
    height: 60px;
    bottom: 40px;
    background-color: #25d366;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
    left: 15px;
}

.my-float {
    margin-top: 16px;
}
  </style>
</head>

<body>

 <!-- Query sending -->
<?php   
include 'dbcon.php';
if(isset($_POST['submit'])){
    $Username = mysqli_real_escape_string($con,$_POST['Username']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $mobile= mysqli_real_escape_string($con, $_POST['mobile']);
    $Query_group =mysqli_real_escape_string($con, $_POST['Query_group']);
    $Query_text =mysqli_real_escape_string($con, $_POST['Query_text']);
    
    $emailquery = " select * from Query where email = '$email' ";
    $query = mysqli_query($con , $emailquery);
    
    $email_count= mysqli_num_rows($query);
    if($email_count>0){
        $userdata = mysqli_fetch_array($query);
        $Username = $userdata['Username'];
        #$token = bin2hex(random_bytes(15));
        $token = $userdata['token'];
        $insertquery = "insert into  Query (Username, email, mobile, Query_group, Query_text,token,status) 
            values ('$Username','$email','$mobile','$Query_group','$Query_text','$token','inactive')"; 
            $iquery = mysqli_query($con , $insertquery);
            $subject ="Query submitted to the team Tortilicious";
            $body = " Hey, $Username. We have noted your Query And will get back to you soon Till then have a Delicious Day
            http://localhost/tortilicious/demo/feane-html/index.php?token=$token&";
            ini_set("SMTP","mail.gmail.com");
           
            // Please specify an SMTP Number 25 and 8889 are valid SMTP Ports.
            ini_set("smtp_port","587");
            
            // Please specify the return address to use
            ini_set('sendmail_from', 'tortilicious2@gmail.com');
        
            #$headers .= 'From : tortilicious2@gmail.com>';
            $headers= 'From: tortilicious2@gmail.com' . "\r\n" .
                        'Reply-To: tortilicious2@gmail.com' . "\r\n" .
                            'X-Mailer: PHP/' . phpversion();
            
            
            if(mail($email,$subject,$body,$headers))
            {
                echo " Check out you Mail Inbox to see your submitted Query";
                $_SESSION['msg'] =" Check out you Mail Inbox to see your submitted Query$email";
                #header('Location:login.php');
            }else{
                echo "Email sending failed";
            }
    }else{
      echo "No Email found";
    }
}

?>

  <div class="hero_area">
    <div class="bg-box">
      <img src="images/hero-bg.jpg" alt="">
    </div>
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.php">
            <span>
              Tortilicious
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mx-auto ">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="menu.php">Menu</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="feed.php">Studio</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
              </li>


              <li class="nav-item">
                <a class="nav-link" href="book.php">Profile Section</a>
              </li>
            </ul>
            <div class="user_option">
              <form class="form-inline">
                <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit">
                  <i class="fa fa-search" aria-hidden="true"></i>
                </button>
              </form>
              <a href="logout.php" class="order_online">
                logout
              </a>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section ">
      <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      <h1 class="mt-0 mb-0"><?php echo "Hey ".$_SESSION['Username'] ; ?></h1>
                    </h1>

                    <h3 class="mt-0 mb-0"> Your kitchen is never been this delicious...! </h3>

                    <div class="btn-box">
                      <a href="feed.php" class="btn1">
                        Studio
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      <h1 class="mt-0 mb-0"><?php echo "Hey ".$_SESSION['Username'] ; ?></h1>
                    </h1>
                    <h3 class="mt-0 mb-0"> Your kitchen is never been this delicious...! </h3>
                    <div class="btn-box">
                      <a href="feed.php" class="btn1">
                        Studio
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      <h1 class="mt-0 mb-0"><?php echo "Hey ".$_SESSION['Username'] ; ?></h1>
                    </h1>


                    <h3 class="mt-0 mb-0"> Your kitchen is never been this delicious...! </h3>
                    <div class="btn-box">
                      <a href="feed.php" class="btn1">
                        Studio
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="container">
          <ol class="carousel-indicators">
            <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
            <li data-target="#customCarousel1" data-slide-to="1"></li>
            <li data-target="#customCarousel1" data-slide-to="2"></li>
          </ol>
        </div>
      </div>

    </section>
    <!-- end slider section -->
  </div>

  <!-- offer section -->

  <section class="offer_section layout_padding-bottom">
    <div class="offer_container">
      <div class="container ">
        <div class="row">
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="images/o1.jpg" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Sunday Specials
                </h5>

                <a href="">
                  Try it!!


                </a>
              </div>
            </div>
          </div>
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="images/o2.jpg" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Tortilicious Special
                </h5>

                <a href="">
                  Try it!!


                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end offer section -->

  <!-- food section -->

  <section class="food_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Our Menu
        </h2>
      </div>

      <ul class="filters_menu">
        <li class="active" data-filter="*">All</li>
        <li data-filter=".burger">Meal Plan</li>
        <li data-filter=".pizza">Cuisines</li>
      </ul>

      <div class="filters-content">
        <div class="row grid">
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f1.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Breakfast
                  </h5>
                  <p>
                    You will get The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f2.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Lunch
                  </h5>
                  <p>
                    You will The get  Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>


                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f3.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Dinner
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>




                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f4.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Kitty Party Meal
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>



                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f5.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Quick and Easy Recipes
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f6.png" alt="">
                </div>
                <div class="detail-box">

                  <h5>
                    Picinc
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f7.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Baking
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f8.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Indian Sweets
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>





                  </div>
                </div>
              </div>
            </div>
          </div>

          <!----Cuisines Page class pizza-->

          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f1.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Italian
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f2.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Guajarti
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>


                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f3.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    South Indian
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>




                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f4.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Punjabi
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>



                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/f5.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Chinese
                  </h5>
                  <p>
                    You will The Best Recipes,according to your Taste, flavours , choice and varietes of new
                    implementations.So what you waiting for visit Fast!!!
                  </p>
                  <div class="options">
                    <a href="">
                      R
                    </a>
                  </div>
                </div>
              </div>
            </div>



            <div class="btn-box">
              <a href="menu.php">
                View More
              </a>
            </div>
          </div>
  </section>

  <!-- end food section -->

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container  ">

      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/about-img.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                Tortilicious , something for everyone !
              </h2>
            </div>
            <p>
              On this platform, we strive to cover every recipe that a modern-day homemaker would need to know about.
              This includes social networking, which allows you to locate a recipe in a matter of seconds while
              listening to music. Not only can you get general/specific recipes for the items you select, but you can
              also locate unique content and recipes from well-known chefs, as well as track them for future recopies.
              This simple-looking portal is an all-in-one resource for foodies, with everything from social media to a
              recipe app. The Social Media Hat also provides a recommended list of your favourite dishes, allowing you
              to put what you've learned from the recipe into practise. So what are you waiting for, if you haven't
              already? Take a look around & have a healthy day!!
            </p>
            <a href="about.php">
              Read More
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->
 
<section class="book_section layout_padding">
<div class="container"> 
<div class="d-flex justify-content-center h-100">
	<div class="card mx-auto" style="max-width: 500%;">
			<div class="card-header">
	<h1>Send your Query</h1>

	 
	<form action="" method="POST">
	<div class="form-group input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
        <input name="Username" class="form-control" placeholder="Full name" type="text" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
		 </div>
        <input name="email" class="form-control" placeholder="Email address" type="email" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
		</div>
		<select class="custom-select" style="max-width: 120px;">
		    <option selected="">+91</option>
		    <option value="1">+972</option>
		    <option value="2">+198</option>
		    <option value="3">+701</option>
		</select>
    	<input name="mobile" class="form-control" placeholder="Phone number" type="text" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-building"></i> </span>
		</div>
        
		<select name = "Query_group" class="form-control" required>
			<option selected=""> Select your query type </option>
			
			<option>Uploding recipies</option>
			<option>Searching recipies</option>
      <option>While watching the Studio</option>
      <option>In doing chat with the other user</option>
            
		</select>
        
	</div>
  <div class="form-group input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
        <input name="Query_text" class="form-control" placeholder="Write your query" type="text" required>
    </div>
    
    <!-- form-group end.// -->

 <!-- form-group// -->                                      
    <div class="form-group">
        <button type="submit" name="submit" class="btn btn-primary btn-block"> Send now  </button>
    </div> <!-- form-group// -->      
                                                                
</form>

</article>
</div> <!-- card.// -->

</div> 
<!--container end.//-->
</div>
</div>
</div>
<div></div>
  <!-- book section -->
 
  <!-- end book section -->

  <!-- client section -->

  <section class="client_section layout_padding-bottom">
    <div class="container">
      <div class="heading_container heading_center psudo_white_primary mb_45">
        <h2>
          What Says Our Users
        </h2>
      </div>
      <div class="carousel-wrap row ">
        <div class="owl-carousel client_owl-carousel">
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <p>
                  Awesome Experience with Exiciting Dishesss!!!!
                </p>
                <h6>
                  Riya Sharma
                </h6>
                <p>
                  Rajkot
                </p>
              </div>
              <div class="img-box">
                <img src="images/client1.jpg" alt="" class="box-img">
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <p>
                  Awesome Experience with Exiciting Dishesss!!!!
                </p>
                <h6>
                  Rohit Sehgal
                </h6>
                <p>
                  Ahemdabad
                </p>
              </div>
              <div class="img-box">
                <img src="images/client2.jpg" alt="" class="box-img">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  

  <!-- end client section -->

  <!-- footer section -->
  <footer class="footer_section">
    <div class="container">
      <div class="row">
        <div class="col-md-4 footer-col">
          <div class="footer_contact">
            <h4>
              Contact Us
            </h4>
            <div class="contact_link_box">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +917817820781/+918347063168
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  tortilicious2@gmail.com
                </span>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <div class="footer_detail">
            <a href="" class="footer-logo">
              Tortilicious
            </a>
            <p>
              We are here to make your work easier, flexible and moreover interesting...
              <div class="footer_social">
                <a href="">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a href="">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
                <a href="">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a href="">
                  <i class="fa fa-pinterest" aria-hidden="true"></i>
                </a>
              </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <h4>
            Contacting Time
          </h4>
          <p>
            Everyday
          </p>
          <p>
            10.00 Am -10.00 Pm
          </p>
        </div>
      </div>
      <div class="footer-info">
        <p>
          &copy; <span id="displayYear"></span> All Rights Reserved By
          <a href="">Tortilicious developers</a>
        </p>
      </div>
    </div>
  </footer>
  <div class="whatsapp"><a title="Whatsapp"  target="_blank" href="https://wa.me/917817820781?text=Hello%20Hema%20Paun"><i class="fa fa-whatsapp my-float"></i></a>
  <!-- footer section -->

  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- isotope js -->
  <script src="https://unpkg.com/isotope-layout@3.0.4/dist/isotope.pkgd.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

</body>

</html>