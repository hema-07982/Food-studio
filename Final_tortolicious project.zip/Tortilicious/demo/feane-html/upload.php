<?php
// Include the database configuration file
include 'dbcon.php';
$statusMsg = '';

// File upload path
$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);


if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $description= mysqli_real_escape_string($con,$_POST['description']);
   


    $allowTypes = array('jpg','png','jpeg','gif','pdf','jfif','mp4');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
            $insert = $con-> query("INSERT into profile_images (file_name, uploaded_on, description) VALUES ('".$fileName."', NOW(),'$description')");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
                header('location:/tortilicious/demo/feane-html/book.php');
            }else{
                $statusMsg = "File upload failed, please try again.";
                header('location:/tortilicious/demo/feane-html/book.php');
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
            header('location:/tortilicious/demo/feane-html/book.php');
        }
    }else{
        $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
        header('location:/tortilicious/demo/feane-html/book.php');
    }
}else{
    $statusMsg = 'Please select a file to upload.';
    header('location:/tortilicious/demo/feane-html/book.php');
}

// Display status message
echo $statusMsg;
?>