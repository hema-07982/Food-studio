<?php

session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<style>
     @import url('https://fonts.googleapis.com/css?family=Numans');
	@import url('https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap');
html,body{
background-image: url('https://c8.alamy.com/comp/2AW9G50/cooking-banner-background-with-spices-and-vegetables-top-view-free-space-for-your-text-2AW9G50.jpg');
background-size: cover;
background-repeat: no-repeat;
height: 100%;
font-family: 'Numans', sans-serif;

}

.container{
	position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
		padding: 3px;
    
}

.card{
height: 500px;
margin-top: auto;
margin-bottom: auto;
width: 400px;
background-color: rgba(0,0,0,0.6) !important;
}

.social_icon span{
font-size: 60px;
margin-left: 10px;
color: #FFC312;
}

.social_icon span:hover{
color: white;
cursor: pointer;
}

.card-header h1{
color: white;
text-align:center;
padding:10px;
font-family: 'Dancing Script', cursive;

}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #FFC312;
color: black;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: black;
background-color: #FFC312;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
img{
    height:150px;
    width:100%;
    border-width:2px;
	border-style:solid;
	padding: 1px 1px 1px 1px;
}
.text-center{
    color:white;
    
}

</style>
<head>
        <title></title>
        <?php include 'css/style.php' ?>
        <?php include 'links/links.php' ?>
</head>
<body>

<?php   
include 'dbcon.php';
;
if (isset($_POST['submit'])) {
    if(isset($_GET['token'])) {
        $token = $_GET['token'];

        $U_Password_new = mysqli_real_escape_string($con, $_POST['Password_new']);
        $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

        $pass = password_hash($U_Password_new, PASSWORD_BCRYPT);
        $cpass = password_hash($cpassword, PASSWORD_BCRYPT);

        
        if ($U_Password_new == $cpassword) {
            $updatequery = " update registration set Password_new = '$pass' where token = '$token'";
         
            $iquery = mysqli_query($con, $updatequery);
            if ($iquery) {
                $_SESSION['passmsg'] = "your password has been updated";
                header("Location:login.php");
            }else {
                $_SESSION['passmsg'] = " Your password is not updated. Please try again";
                header("Location:reset_password.php?token=$token&");
            }
        }else {
            $_SESSION['passmsg'] = " Your password is not matching. Please try again";
            header("Location:reset_password.php?token=$token&");
        }
    }else {
        echo "No token found. Please try again";
    }
}
#$2y$10$yoC6LTZ51SLMGP1JW5Ozk.P23c5FkWAkQQ7IgyiR/82..


?>
<div class="container">  
<div class="d-flex justify-content-center h-100">
	<div class="card mx-auto" style="max-width: 500%;">
		<div class="card-header">
            <h1>Reset Password</h1>

	<p class="text-center">Please enter your new password</p>
	<p class = "bg-info text-white px-5" >
    <p>
            <img src="images/logo.jpeg">
	</p> <?php 
    if(isset($_SESSION['passmsg'])){
        echo $_SESSION['passmsg'];
    }else{
        echo $_SESSION['passmsg'] ="";

    }
    
    ?></p>
	<form action="" method="POST">
	 <!-- form-group// -->
     <!-- form-group// -->
     <!-- form-group// -->
     <!-- form-group end.// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Create new password" type="password" name="Password_new" value=""required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Confirm  password" type="password" name="cpassword" value=""required>
    </div> <!-- form-group// -->                                      
    <div class="form-group">
        <button type="submit" name="submit" class="btn btn-primary btn-block"> Reset Password </button>
    </div> <!-- form-group// -->      
                                                                     
</form>
</div>
</div> <!-- card.// -->

</div> 
</div>
<!--container end.//-->    
</body>
</html>
