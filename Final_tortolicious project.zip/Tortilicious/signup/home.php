
<!DOCTYPE html>
<html>
<head>
        <title></title>
        <?php include 'css/home_style.php' ?>
        
</head>
<body>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Responsive Drop-down Menu Bar</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="file:///E:/fontawesome/css/all.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="file:///E:/jquery.js"></script>
  </head>
  <body>
    <nav>
      <div class="logo">FoodieZone</div>
      <label for="btn" class="icon">
        <span class="fa fa-bars"></span>
      </label>
      <input type="checkbox" id="btn">
      <ul>
        <li><a href="#">Studio</a></li>
        <li>
          <label for="btn-1" class="show">Categories +</label>
          <a href="#">Categories</a>
          <input type="checkbox" id="btn-1">
          <ul>
            <li><a href="#">Meal Plan +</a>
                <ul>
                  <li><a href="#">Breakfast</a></li>
                    <li><a href="#">Lunch</a></li>
                    <li><a href="#">Dinner</a></li>
                    <li><a href="#">Kitty party meal</a></li>
                    <li><a href="#">Quick and easy</a></li>
                    <li><a href="#">Picnic recipies</a></li>
                    <li><a href="#">Baking</a></li>
                    <li><a href="#">Sweets and Desserts</a></li>
                  </ul>
            </li>
            <li><a href="#">Cuisins +</a>
                <ul>
                    <li><a href="#">Italian</a></li>
                    <li><a href="#">Gujarati</a></li>
                    <li><a href="#">Punjabi</a></li>
                    <li><a href="#">Chinese</a></li>
                    <li><a href="#">Mexican</a></li>
                    <li><a href="#">Kid Friendly</a></li>
                     
                  </ul>
            
            
            
            </li>
             
          </ul>
        </li>
        
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Profile</a></li>
        <li><a href="logout.php">Logout</a></li>

      </ul>
    </nav>
    <div class="content">
        <h1> Hello <?php echo $_SESSION['Username'] ; ?></h1>
        <h2> Welcome to the world of food</h2>
  
    </div>
    <script>
      $('.icon').click(function(){
        $('span').toggleClass("cancel");
      });
    </script>
    

  </body>
</html>
 
