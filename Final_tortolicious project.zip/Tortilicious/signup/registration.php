<?php

session_start();
?>
<!DOCTYPE html>
<html>
<style>
     @import url('https://fonts.googleapis.com/css?family=Numans');
	@import url('https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap');
html,body{
background-image: url('https://c8.alamy.com/comp/2AW9G50/cooking-banner-background-with-spices-and-vegetables-top-view-free-space-for-your-text-2AW9G50.jpg');
background-size: cover;
background-repeat: no-repeat;
height: 100%;
font-family: 'Numans', sans-serif;

}

.container{
	position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
		padding: 3px;
    
}

.card{
height: 720px;
margin-top: auto;
margin-bottom: auto;
width: 400px;
background-color: rgba(0,0,0,0.6) !important;
}

.social_icon span{
font-size: 60px;
margin-left: 10px;
color: #FFC312;
}

.social_icon span:hover{
color: white;
cursor: pointer;
}

.card-header h1{
color: white;
text-align:center;
padding:10px;
font-family: 'Dancing Script', cursive;

}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #FFC312;
color: black;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: black;
background-color: #FFC312;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
img{
    height:150px;
    width:100%;
    border-width:2px;
	border-style:solid;
	padding: 1px 1px 1px 1px;
}
.text-center{
    color:white;
    
}

</style>
<head>
        <title></title>
        <?php include 'css/style.php' ?>
        <?php include 'links/links.php' ?>
    
</head>
<body>

<?php   
include 'dbcon.php';
if(isset($_POST['submit'])){
    $Username = mysqli_real_escape_string($con,$_POST['Username']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $mobile= mysqli_real_escape_string($con, $_POST['mobile']);
    $Age_group =mysqli_real_escape_string($con, $_POST['Age_group']);
    $Password_new =mysqli_real_escape_string($con, $_POST['Password_new']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

    $pass = password_hash($Password_new, PASSWORD_BCRYPT);
    $cpass = password_hash($cpassword, PASSWORD_BCRYPT);
    $token= bin2hex(random_bytes(15));
    $emailquery = " select * from registration where email = '$email' ";
    $query = mysqli_query($con , $emailquery);

    $emailcount= mysqli_num_rows($query);
    if($emailcount>0){
        ?>
                 <script >
                    alert("Email already exists!!");
                 </script>
        <?php

    }else{
        if ($Password_new == $cpassword){
            
            $insertquery = "insert into  registration (Username, email, mobile, Age_group, Password_new, cpassword,token,status) 
            values ('$Username','$email','$mobile','$Age_group','$pass','$cpass','$token','inactive')"; 
            $iquery = mysqli_query($con , $insertquery);
            if ($iquery) {
                ?>
                 <script >
                    alert("Inserted successful");
                 </script>
                <?php
                }else{
                    ?>
                    <script >
                        alert(" Unsuccessful insertion ");
                    </script>
                    <?php
                }

        }else {
            ?>
                <script >
                    alert(" Password and confirm password are not same  ");
                </script>
            <?php
        }
    }
}

?>
<div class="container"> 
<div class="d-flex justify-content-center h-100">
	<div class="card mx-auto" style="max-width: 500%;">
			<div class="card-header">
	<h1>Create Account</h1>
	<p class="text-center">Get started with your free account</p>
	<p>
            <img src="images/logo.jpeg">
	</p>
	 
	<form action="" method="POST">
	<div class="form-group input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
        <input name="Username" class="form-control" placeholder="Full name" type="text" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
		 </div>
        <input name="email" class="form-control" placeholder="Email address" type="email" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
		</div>
		<select class="custom-select" style="max-width: 120px;">
		    <option selected="">+91</option>
		    <option value="1">+972</option>
		    <option value="2">+198</option>
		    <option value="3">+701</option>
		</select>
    	<input name="mobile" class="form-control" placeholder="Phone number" type="text" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-building"></i> </span>
		</div>
        
		<select name = "Age_group" class="form-control" required>
			<option selected=""> Select Your Age Group </option>
			<option>10-20</option>
			<option>20-30</option>
			<option>30-40</option>
            <option>40-50</option>
            <option>50-60</option>
            <option>60-70</option>
		</select>
        
	</div> <!-- form-group end.// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Create password" type="password" name="Password_new" value=""required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Confirm  password" type="password" name="cpassword" value=""required>
    </div> <!-- form-group// -->                                      
    <div class="form-group">
        <button type="submit" name="submit" class="btn btn-primary btn-block"> Create Account  </button>
    </div> <!-- form-group// -->      
    <p class="text-center"> Already Have an account? <a href="Login.php">Log In</a> </p>                                                                 
</form>
</article>
</div> <!-- card.// -->

</div> 
<!--container end.//-->
</div>
</div>
</div>
<div>   
</body>
</html>
