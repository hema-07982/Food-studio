<?php

session_start();
?>

<!DOCTYPE html>
<html>
<style>
     @import url('https://fonts.googleapis.com/css?family=Numans');
	@import url('https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap');
html,body{
background-image: url('https://c8.alamy.com/comp/2AW9G50/cooking-banner-background-with-spices-and-vegetables-top-view-free-space-for-your-text-2AW9G50.jpg');
background-size: cover;
background-repeat: no-repeat;
height: 100%;
font-family: 'Numans', sans-serif;

}

.container{
	position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
		padding: 3px;
    
}

.card{
height: 500px;
margin-top: auto;
margin-bottom: auto;
width: 400px;
background-color: rgba(0,0,0,0.6) !important;
}

.social_icon span{
font-size: 60px;
margin-left: 10px;
color: #FFC312;
}

.social_icon span:hover{
color: white;
cursor: pointer;
}

.card-header h1{
color: white;
text-align:center;
padding:10px;
font-family: 'Dancing Script', cursive;

}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #FFC312;
color: black;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: black;
background-color: #FFC312;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
img{
    height:150px;
    width:100%;
    border-width:2px;
	border-style:solid;
	padding: 1px 1px 1px 1px;
}
.text-center{
    color:white;
    
}

</style>

<head>
        <title></title>
        <?php include 'css/style.php' ?>
        <?php include 'links/links.php' ?>
</head>
<body>

<?php   
include 'dbcon.php';
if(isset($_POST['submit']))
{
   
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $emailquery = " select * from registration where email = '$email' ";
    $query = mysqli_query($con , $emailquery);
    
    $email_count= mysqli_num_rows($query);
    if($email_count>0){
        $userdata = mysqli_fetch_array($query);
        $Username = $userdata['Username'];
        #$token = bin2hex(random_bytes(15));
        $token = $userdata['token'];
            $subject ="Password Reset";
            $body = " Hey, $Username. Click here to recover Your password
            http://localhost/tortilicious/signup/reset_password.php?token=$token&";
            ini_set("SMTP","mail.gmail.com");
           
            // Please specify an SMTP Number 25 and 8889 are valid SMTP Ports.
            ini_set("smtp_port","587");
            
            // Please specify the return address to use
            ini_set('sendmail_from', 'tortilicious2@gmail.com');
        
            #$headers .= 'From : tortilicious2@gmail.com>';
            $headers= 'From: tortilicious2@gmail.com' . "\r\n" .
                        'Reply-To: tortilicious2@gmail.com' . "\r\n" .
                            'X-Mailer: PHP/' . phpversion();
            
            
            if(mail($email,$subject,$body,$headers))
            {
                echo " Check out you Mail Inbox to reset your password";
                $_SESSION['msg'] =" Check out you Mail Inbox to reset your password $email";
                #header('Location:login.php');
            }else{
                echo "Email sending failed";
            }
    }else{
      echo "No Email found";
    }
}
?>
<div class="container">  
<div class="d-flex justify-content-center h-100">
	<div class="card mx-auto" style="max-width: 500%;">
			<div class="card-header">
	<h1>Recover your Account</h1>
            <p class="text-center"> Please fill out the Email id </p>
            <p>
            <img src="images/logo.jpeg">
	        </p>
            <form action="" method="POST">
                <!-- form-group// -->
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                    </div>
                    <input name="email" class="form-control" placeholder="Email address" type="email" required>
                </div> <!-- form-group// -->
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-block"> Send mail </button>
                </div> <!-- form-group// -->
                <p class="text-center"> Already Have an account? <a href="Login.php">Log In</a> </p>
            </form>
</div>
</div> <!-- card.// -->
</div>
</body>
</html>
